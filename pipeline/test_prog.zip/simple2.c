int foo()
{
	int a = 100;
	return a;
}
