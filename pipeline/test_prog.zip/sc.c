#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "inst.h"

char* path = "input4.bin";

struct ifid{
        int inst;
        int pc4;

};//lat1

struct idex{
        int alu1;
        int alu2;
        int v2;
        int wreg;
        int pc4;
        int imm;
};//lat2

struct exmem{
        int aluresult;
        int v2;
        int wreg;
};//lat3

struct memwb{
        int wdata;
        int wreg;
};//lat4

//for pcupdate//
int pc4, branchAddr, jumpAddr, jrjump;

int rs,rt,rd;
int opcode, shamt, funct, imm, address, extimm;
//void setMUX();
/////////mem and reg/////////
int pc;
int reg[32];
int mem[0x100000];

///////control signal/////
int regDst,aluSrc,memtoReg,memWrite,memRead,regWrite,jump,branch;
int bcond, br_taken;

//latch//
struct ifid lat1[2];
struct idex lat2[2];
struct exmem lat3[2];
struct memwb lat4[2];

/////////funct////
void control(int opcode);


///funct(5)////
void fetch(int cycle);
void decode(int inst);
void execute();
void memory();
void writeback();

//////////prinf

void print_inst(){
if(opcode==0){
//printf("opcode : 0x%x , rs : %d, rt : %d, rd : %d,shamt : %d, funct: 0x%x \n", opcode, rs, rt, rd, shamt, funct);
}
else if((opcode==0x3)||(opcode==0x2)){
//printf("opcode : 0x%x , addr : 0x%x \n", opcode, address);
}
else{
//printf("opcode : 0x%x , rs : %d, rt : %d, imm : 0x%08x\n",opcode, rs, rt, lat2[1].imm);
}
}

////////////////main////////////////
void main(int argc, char *argv[]){

//for open file and store inst to memory/////
        FILE* fp = NULL;
  // char* path = "simple.bin";
   int val = 0;
   int res;
   int inst;
   int num = 0;
        int cycle=0;
/////////////////////////////////////////////

//initialize registers and pc
        pc = 0;
memset(reg,0,32);//all of register initialize to 0
reg[29] = 0x400000;
reg[31] = 0xffffffff;

if(argc == 2){path=argv[1];}

fp = fopen(path, "rb");
if(fp==NULL){
        printf("invalid input file: %s\n",path);
        return ;}

while(1){
   res = fread(&val, 4,  1, fp);
   if(res == 0)break;

        inst = (val&0xFF) << 24
           | (val&0xFF00) << 8
           | (val&0xFF0000) >> 8
           | (val&0xFF000000) >> 24;
   mem[num] = inst;
   num++;
} // inst -> memory (store all of instruction to memory)

//printf("/////////////////instruction//////////////////\n");

while(1){

cycle++;

fetch(cycle);


if(pc==0xffffffff) break;
//printf("\n-----------[cycle %d]-----------\n",cycle);

lat1[1]=lat1[0];
//printf("[pc]\t %08x\n",pc);

decode(lat1[1].inst);
//printf("[inst]\t %08x\n",lat1[1].inst);
lat2[1]=lat2[0];


execute();
lat3[1]=lat3[0];
print_inst();

memory();
lat4[1]=lat4[0];
//if(memWrite==1)//printf("[memory] mem[%x] : %x\n",lat3[1].aluresult, lat3[1].v2);

writeback();
if(regWrite==1){
//printf("[WB]\t r[%d] : 0x%08x\n", lat4[1].wreg, reg[lat4[1].wreg]);
}
if(opcode==jal){
//printf("r[31] : 0x%08x\n", reg[31]);
}

}

printf("\n---------result-----------\n");
printf("\nreturn value %d\t cycle %d \n\n",reg[2],cycle);


return ;

}//end of main

void fetch(int cycle){ // memory -> CPU

pc4=pc+4;

if(jump==1){
        if((opcode==jal)||(opcode==j)){
                jumpAddr=(jumpAddr&0x0FFFFFFF)|(pc4&0xF0000000);
                pc=jumpAddr;
        }
        else if(funct==jr){pc=jrjump;}
}
else if(br_taken==1)    pc=branchAddr;

else    pc=pc4;


if(cycle==1){pc=0; pc4=4;}

lat1[0].inst=mem[pc/4];
lat1[0].pc4=(pc+4);

return ;
}





void decode(int inst){
        opcode = (inst&0xFC000000) >> 26;
//printf("0x%x \n", opcode);
        rs=0; rt=0; rd=0;
        shamt=0; funct=0; imm=0; address=0;
/*
        rs = (inst&0x03E00000) >> 21;
        rt = (inst&0x001F0000) >> 16;
        rd = (inst&0x0000F800) >> 11;
        shamt = (inst&0x000007C0) >> 6;
        funct = inst&0x0000003F;
        address = inst&0x03FFFFFF;
        imm = inst&0x0000FFFF;
*/
     if(opcode == 0){ // R-type

                rs = (inst&0x03E00000) >> 21;
                rt = (inst&0x001F0000) >> 16;
                rd = (inst&0x0000F800) >> 11;
                shamt = (inst&0x000007C0) >> 6;
                funct = inst&0x0000003F;
        }
        else if(opcode == 2 || opcode == 3){ //J-type(j, jal)
                address = inst&0x03FFFFFF;
                jumpAddr = address<<2;
                }

        else{ //I -type
                rs = (inst&0x03E00000) >> 21;
                rt = (inst&0x001F0000) >> 16;
                imm = inst&0x0000FFFF;
  if((opcode==andi)||(opcode==ori)){imm = imm&0x0000FFFF;}
        else{
            if((imm>>15)==1){imm = imm|0xFFFF0000;}
                else {imm = imm&0x0000FFFF;}
            }



}


 control(opcode);

        int con1;
        int con2;
        if(aluSrc==1) {con1=imm;}
                else {con1=reg[rt];}

        if(regDst==1) {con2=rd;}
                else {con2=rt;}

        lat2[0].alu1=reg[rs];
    lat2[0].alu2=con1;
    lat2[0].v2=reg[rt];
    lat2[0].wreg=con2;
    lat2[0].pc4=lat1[1].pc4;
        lat2[0].imm=imm;

        jrjump=reg[rs];


return ;

}

void execute(){ // ALU, result means ALU result

        int aluData1=lat2[1].alu1;
        int aluData2=lat2[1].alu2;
        int result;

switch(opcode){
        case addi: //addi overflow X
                result=aluData1+aluData2;
                break;

        case addiu: //addiu overflow O
                result=aluData1+aluData2;
                break;

        case andi: //and
                result=aluData1&aluData2;
                break;

        case beq: //beq
                if(aluData1==aluData2){
                bcond = 1;}
                else{bcond = 0;}
                break;

        case bne: //bne
                if(aluData1!=aluData2){
                bcond =1;}
                else{bcond = 0;}
                break;

        case j: //j
                result = address;
                break;

        case jal: //jal
                reg[31]=pc+8;
                break;

        case lbu: // ibu
                result = aluData1+aluData2;
                break;

        case lhu: //lhu
                result = aluData1+aluData2;
                break;

        case ll: //ll
                result=aluData1+aluData2;
                break;

        case lui: //lui
                result=(aluData2<<16);
                break;

        case lw://lw
                result=aluData1+aluData2;
                break;

        case ori: //ori
                result=aluData1|aluData2;
                break;

        case slti:
                if(aluData1<aluData2){result=1;}
                else{result=0;}
                break;

        case sb: //sb
                result = aluData1+aluData2;
                break;

        case sh: //sh
                result = aluData1+aluData2;
                break;

        case sw: //sw
                result = aluData1+aluData2;
                break;

case 0: // R_type
        switch(funct){

        case add: //add
                result = aluData1+aluData2;
                break;

        case addu:  //addu
                result = aluData1+aluData2;
                break;

        case and: //and
                result=aluData1&aluData2;
                break;

        case jr: // jr
                result = aluData1;
                break;

        case nor://nor
                result=0xffffffff-(aluData1|aluData2);
                break;

        case or: //or
                result=(aluData1|aluData2);
                break;

        case slt: //slt
                if(aluData1<aluData2){result=1;}
                else{result=0;}
                break;

        case sltu: //sltu
                if(aluData1<aluData2){result=1;}
                else{result=0;}
                break;

        case sll: //sll
                result=aluData2<<shamt;
                break;

        case srl: //srl
                result=aluData2>>shamt;
                break;

        case sub: //sub
                result=aluData1-aluData2;
                break;

        case subu: //subu
                result=aluData1-aluData2;
                break;

}//R_type

}//end of switch(opcode)
//print_inst(); // printf instruction
br_taken = bcond&branch; // for branch

lat3[0].aluresult=result;
lat3[0].v2=reg[rt];
lat3[0].wreg=lat2[1].wreg;

if(br_taken==1){
branchAddr=((lat2[1].imm)<<2)+(lat2[1].pc4);
}
//calc branch

return ;
} // end of execute



void memory(){
//basic set, after ALU


if(memRead==1)  lat4[0].wdata=mem[lat3[1].aluresult/4];

if(memWrite==1) mem[lat3[1].aluresult/4]=lat3[1].v2;

if(memtoReg==1) lat4[0].wdata=mem[lat3[1].aluresult/4];
        else lat4[0].wdata=lat3[1].aluresult;

lat4[0].wreg=lat3[1].wreg;
return ;
}

void writeback(){
if(regWrite==1)
        reg[lat4[1].wreg] = lat4[1].wdata;
return ;
}



//set control signal
void control(int opcode){
        if(opcode == 0){regDst=1;}
                else{regDst = 0;}

        if((opcode!=0)&&(opcode!=beq)&&(opcode!=bne)) {aluSrc=1;}
                else{aluSrc=0;}

        if((opcode==lw)||(opcode==ll)){ memtoReg =1;}
                else{memtoReg = 0;}

        if((opcode!=jal)&&(opcode!=sw)&&(opcode!=sh)&&(opcode!=sb)&&(opcode!=beq)&&(opcode!=bne)&&(opcode!=j)&&(funct!=jr)){ regWrite=1;}
               else{regWrite = 0;}

        if((opcode==lw)||(opcode==ll)||(opcode==lbu)||(opcode==lhu)){memRead = 1;}
                else{memRead = 0;}

        if((opcode==sw)||(opcode==sh)||(opcode==sb)){ memWrite=1;}
                else{memWrite=0;}

        if((opcode==j)||(opcode==jal)||(funct==jr)){jump=1;}
                else{jump = 0;}

        if((opcode==bne)||(opcode==beq)){branch=1;}
                else{branch = 0;}



//print control signal
//printf("regdst %d, alusrc %d, memtoreg %d, regwrite %d, memread %d, memwrite %d, jump %d, branch %d \n", regDst,aluSrc, memtoReg,regWrite, memRead, memWrite, jump, branch );

return ;
}

