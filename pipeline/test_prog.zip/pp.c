#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "inst.h"

//bne -> cycle qq
struct ifid{
        int valid;
        int inst, pc4;
        int pc;
};//lat1

struct idex{
        int valid;
        int pc;
        int alu1,alu2,v2,wreg,pc4,imm;
        int rs, rt;
        int jump, regDst, aluSrc, memtoReg, memWrite, memRead, regWrite, branch;
	int jumpAddr, funct, opcode;
};//lat2

struct exmem{
        int valid;
        int pc;
        int aluresult,v2,wreg;
        int rs, rt;
        int memtoReg,memWrite,memRead,regWrite;
};//lat3

struct memwb{
        int valid;
        int pc;
        int wdata,wreg;
        int regWrite;
};//lat4

//for pcupdate//
int pc4, branchAddr, jrjump;
int cycle;
int rs,rt,rd;
int opcode, shamt, funct, imm, address, extimm;
int endloop;
/////////mem and reg/////////
int pc;
int reg[32];
int mem[0x100000];

int br_taken, jump;

//latch//
struct ifid lat1[2];
struct idex lat2[2];
struct exmem lat3[2];
struct memwb lat4[2];

/////////funct////
void control(int opcode);

///funct(5)////
void fetch(int cycle);
void decode(int inst);
void execute();
void memory();
void writeback();

//////////prinf

void print_inst(){
if(opcode==0){
printf("opcode : 0x%x , rs : %d, rt : %d, rd : %d, shamt : %d, funct: 0x%x \n", opcode, rs, rt, rd, shamt, funct);
}
else if((opcode==0x3)||(opcode==0x2)){
printf("opcode : 0x%x , addr : 0x%x \n", opcode, address);
}
else{
printf("opcode : 0x%x , rs : %d, rt : %d, imm : 0x%08x\n",opcode, rs, rt, lat2[0].imm);
}
}

////////////////main////////////////
void main(int argc, char *argv[]){

//for open file and store inst to memory/////
        FILE* fp = NULL;
  // char* path = "simple.bin";
   int val = 0;
   int res;
   int inst;
   int num = 0;
	char* path;

path = (char*)malloc(sizeof(char)*10);
/////////////////////////////////////////////

//initialize registers and pc
pc = 0;
memset(reg,0,32);//all of register initialize to 0
reg[29] = 0x100000;
reg[31] = 0xffffffff;


printf("enter the bin file : ");
scanf("%s",path);
if((strcmp(path,"s1"))==0) path="simple.bin";
if((strcmp(path,"s2"))==0) path="simple2.bin";
if((strcmp(path,"s3"))==0) path="simple3.bin";
if((strcmp(path,"s4"))==0) path="simple4.bin";
if((strcmp(path,"fib"))==0) path="fib.bin";
if((strcmp(path,"gcd"))==0) path="gcd.bin";
if((strcmp(path,"in"))==0) path="input4.bin";

if(argc == 2){path=argv[1];}

fp = fopen(path, "rb");
if(fp==NULL){
        printf("invalid input file: %s\n",path);
        return ;}


memset(lat1,0,sizeof(struct ifid)*2);
memset(lat2,0,sizeof(struct idex)*2);
memset(lat3,0,sizeof(struct exmem)*2);
memset(lat4,0,sizeof(struct memwb)*2);


while(1){
   res = fread(&val, 4,  1, fp);
   if(res == 0)break;

        inst = (val&0xFF) << 24
           | (val&0xFF00) << 8
           | (val&0xFF0000) >> 8
           | (val&0xFF000000) >> 24;
   mem[num] = inst;
   num++;
} // inst -> memory (store all of instruction to memory)

printf("/////////////////instruction//////////////////\n");
for(int x = 0; x < num ; x++){printf("inst%d : 0x%08x\n", x , mem[x]);}

cycle=0;
endloop=0;

while(1){

cycle++;
//if(cycle==300) break;
if(endloop) break;
if(lat1[1].inst==0x03e000008) break;

//if(lat1[1].inst==0x0) break;
if(lat1[1].inst==0x0c0000000) break;

printf("\n-----------[cycle %d]-----------\n\n",cycle);

writeback();
memory();
execute();
decode(lat1[1].inst);
fetch(cycle);

print_inst();

if(br_taken){
lat2[0].valid = 0;
}

lat1[1]=lat1[0];
lat2[1]=lat2[0];
lat3[1]=lat3[0];
lat4[1]=lat4[0];
}

printf("\n---------result-----------\n");
printf("\nreturn value %d\n\n",reg[2]);

return ;
}//end of main


void fetch(int cycle){ // memory -> CPU
int jumpAddr;
int end_pc=pc;

pc4=pc+4;
if((lat2[1].opcode==j)){
   jumpAddr=(lat2[1].jumpAddr&0x0FFFFFFF)|(lat2[1].pc4&0xF0000000);
                pc=jumpAddr;
	printf("jump : 0x%x", pc);
}



if(lat2[1].jump==1){
	if(lat2[1].opcode==jal){
   jumpAddr=(lat2[1].jumpAddr&0x0FFFFFFF)|(lat2[1].pc4&0xF0000000);
   pc=jumpAddr;	
printf("jump : 0x%x / r[31] %x", pc, reg[31]);
}
      else if(lat2[1].funct==jr){ 
pc=jrjump;
//lat1[0].valid=0;
printf("jump : 0x%x", pc);
}
}
else if(br_taken==1)     pc=branchAddr;

else   pc=pc4;


if(cycle==1){pc=0; pc4=4;}

jump=0;
br_taken=0;
pc4=pc+4;

lat1[0].inst=mem[pc/4];
lat1[0].pc4=pc4;
lat1[0].pc=pc;

printf("[pc]\t 0x%08x",pc);
printf("\t[inst]\t 0x%08x\n",lat1[0].inst);


if(end_pc==0xffffffff){
        memset(lat1,0,(sizeof(struct ifid))*2);
        lat1[0].pc=0xffffffff;}

return ;
}



void decode(int inst){
        opcode = (inst&0xFC000000) >> 26;
        rs=0; rt=0; rd=0;
        shamt=0; funct=0; imm=0; address=0;
/*
        rs = (inst&0x03E00000) >> 21;
        rt = (inst&0x001F0000) >> 16;
        rd = (inst&0x0000F800) >> 11;
        shamt = (inst&0x000007C0) >> 6;
        funct = inst&0x0000003F;
        address = inst&0x03FFFFFF;
        imm = inst&0x0000FFFF;
*/
     if(opcode == 0){ // R-type

                rs = (inst&0x03E00000) >> 21;
                rt = (inst&0x001F0000) >> 16;
                rd = (inst&0x0000F800) >> 11;
                shamt = (inst&0x000007C0) >> 6;
                funct = inst&0x0000003F;
	lat2[0].funct=funct;
        }
        else if((opcode == 2) || (opcode == 3)){ //J-type(j, jal)
                address = inst&0x03FFFFFF;
                lat2[0].jumpAddr = address<<2;
                }

        else{ //I -type
                rs = (inst&0x03E00000) >> 21;
                rt = (inst&0x001F0000) >> 16;
                imm = inst&0x0000FFFF;
  if((opcode==andi)||(opcode==ori)){imm = imm&0x0000FFFF;}
        else{
            if((imm>>15)==1){imm = imm|0xFFFF0000;}
                else {imm = imm&0x0000FFFF;}
            }

}

 control(opcode);

        if(lat2[0].aluSrc==1) {lat2[0].alu2=imm;}
                else {lat2[0].alu2=reg[rt];}
//printf("de : alu2 %x \n",lat2[0].alu2);
        if(lat2[0].regDst==1) {lat2[0].wreg=rd;}
                else {lat2[0].wreg=rt;}

        lat2[0].alu1=reg[rs];

    lat2[0].v2=reg[rt];

    lat2[0].pc4=lat1[1].pc4;
        lat2[0].imm=imm;
        lat2[0].pc=lat1[1].pc;
        lat2[0].rs=rs;
        lat2[0].rt=rt;
	lat2[0].opcode=opcode;
	

return ;

}

void execute(){ // ALU, result means ALU result

        int result;
        int bcond=0;
        lat3[0].v2=lat2[1].v2;


//printf("jump %d",lat2[1].jump);

if(lat2[1].jump!=1){

if((lat2[1].rs==lat3[1].wreg)&&(lat2[1].rs!=0)&&(lat3[1].regWrite))//dist=2
       lat2[1].alu1 = lat4[0].wdata;

if((lat2[1].rs==lat4[1].wreg)&&(lat2[1].rs!=0)&&(lat4[1].regWrite))//dist=1
       lat2[1].alu1 = lat4[1].wdata;

if((lat2[1].opcode==0)||(lat2[1].branch==1)){
	if((lat2[1].rt==lat3[1].wreg)&&(lat2[1].rt!=0)&&(lat3[1].regWrite))
		lat2[1].alu2 = lat4[0].wdata;

	if((lat2[1].rt==lat4[1].wreg)&&(lat2[1].rt!=0)&&(lat4[1].regWrite))
		lat2[1].alu2 = lat4[1].wdata;
	}

}

if(lat2[1].funct==jr){

if((lat2[1].rs==lat3[1].wreg)&&(lat2[1].rs!=0)&&(lat3[1].regWrite))//dist=2
       lat2[1].alu1 = lat4[0].wdata;

if((lat2[1].rs==lat4[1].wreg)&&(lat2[1].rs!=0)&&(lat4[1].regWrite))//dist=1
       lat2[1].alu1 = lat4[1].wdata;


}


int aluData1;
aluData1=lat2[1].alu1;
int aluData2;
aluData2=lat2[1].alu2;

//printf("lat2[1].rs %d %d alu1 %d \nlat2[1].rt %d %d alu2 %d \n" ,lat2[1].rs, reg[lat2[1].rs], aluData1, lat2[1].rt, reg[lat2[1].rt], aluData2);

switch(opcode){
        case addi: //addi overflow X
                result=aluData1+aluData2;
                break;

        case addiu: //addiu overflow O
                result=aluData1+aluData2;
                break;

        case andi: //and
                result=aluData1&aluData2;
                break;

        case beq: //beq
                if(aluData1==aluData2){
                bcond = 1;}
                else{bcond = 0;}
                break;

        case bne: //bne
                if(aluData1!=aluData2){
                bcond =1;}
                else{bcond = 0;}
                break;

        case j: //j
                result = address;
                break;

        case jal: //jal
                reg[31]=lat2[1].pc+8;
                break;

        case lbu: // ibu
                result = aluData1+aluData2;
                break;

        case lhu: //lhu
                result = aluData1+aluData2;
                break;

        case ll: //ll
                result=aluData1+aluData2;
                break;

        case lui: //lui
                result=(0xFFFF0000)&(aluData2<<16);
                break;

        case lw://lw
                result=aluData1+aluData2;
                break;

        case ori: //ori
                result=aluData1|aluData2;
                break;

        case slti:
                if(aluData1<aluData2){result=1;}
                else{result=0;}
                break;

        case sb: //sb
                result = aluData1+aluData2;
                break;

        case sh: //sh
                result = aluData1+aluData2;
                break;

        case sw: //sw
                result = aluData1+aluData2;
                break;

case 0: // R_type
        switch(funct){

        case add: //add
                result = aluData1+aluData2;
                break;

        case addu:  //addu
                result = aluData1+aluData2;
                break;

        case and: //and
                result=aluData1&aluData2;
                break;

        case jr: // jr
                result = aluData1;
                break;

        case nor://nor
                result=0xffffffff-(aluData1|aluData2);
                break;

        case or: //or
                result=(aluData1|aluData2);
                break;

        case slt: //slt
                if(aluData1<aluData2){result=1;}
                else{result=0;}
                break;

        case sltu: //sltu
                if(aluData1<aluData2){result=1;}
                else{result=0;}
                break;

        case sll: //sll
                result=aluData2<<shamt;
                break;

        case srl: //srl
                result=aluData1>>shamt;
                break;

        case sub: //sub
                result=aluData1-aluData2;
                break;

        case subu: //subu
                result=aluData1-aluData2;
                break;

        case jalr: // Rtype;
                result=aluData1;
                break;
}//R_type

}//end of switch(opcode)
//print_inst(); // printf instruction

if(lat2[1].funct==jr) jrjump=result;

br_taken = bcond&lat2[1].branch; // for branch


//printf("ex : branch ? %d %d %d\n",br_taken, bcond, lat2[1].branch);
//printf("ex : result %x %d \n",result, result);

lat3[0].aluresult=result;
lat3[0].wreg=lat2[1].wreg;
lat3[0].pc=lat2[1].pc;
lat3[0].rs=lat2[1].rs;
lat3[0].rt=lat2[1].rt;
lat3[0].memtoReg=lat2[1].memtoReg;
lat3[0].memWrite=lat2[1].memWrite;
lat3[0].memRead=lat2[1].memRead;
lat3[0].regWrite=lat2[1].regWrite;

if(br_taken==1){
branchAddr=((lat2[1].imm)<<2)+(lat2[1].pc4);
pc=branchAddr;
}
//calc branch

return ;
} // end of execute



void memory(){
//basic set, after ALU

if(lat3[1].memWrite==1){
//if((lat3[1].v2==lat3[0].wreg)&&(lat2[1].rt!=0)&&(lat3[0].regWrite))	
	if((lat3[1].rt==lat4[1].wreg)&&(lat2[1].rt!=0)&&(lat4[1].regWrite))
		lat3[1].v2=lat4[1].wdata;
//printf("meme data \n");
}

//load
if(lat3[1].memRead==1)  lat4[0].wdata=mem[lat3[1].aluresult];

//store
if(lat3[1].memWrite==1){
printf("mmmmr[0] : %x  r[30] : %x  r[2] : %x\n", reg[0], reg[30], reg[2]);
mem[lat3[1].aluresult]=lat3[1].v2;
printf("[memory] mem[%x] : %x\n",lat3[1].aluresult, lat3[1].v2);

}

if(lat3[1].memtoReg==1) {lat4[0].wdata=mem[lat3[1].aluresult];}
        else {lat4[0].wdata=lat3[1].aluresult;}


lat4[0].wreg=lat3[1].wreg;
lat4[0].pc=lat3[1].pc;
lat4[0].regWrite=lat3[1].regWrite;

return ;
}

void writeback(){
if(lat4[1].regWrite==1){
        reg[lat4[1].wreg] = lat4[1].wdata;
        printf("[WB]\t r[%d] : 0x%08x \n", lat4[1].wreg, lat4[1].wdata);}

        if(lat4[1].pc==0xffffffff) {printf("[wb] pc : 0x%x \n", lat4[1].pc); endloop=1;}

return ;
}



//set control signal
void control(int opcode){
int regDst,aluSrc,memtoReg,memWrite,memRead,regWrite,branch;
        if(opcode == 0){regDst=1;}
                else{regDst = 0;}

        if((opcode!=0)&&(opcode!=beq)&&(opcode!=bne)){aluSrc=1;}
                else{aluSrc=0;}

        if((opcode==lw)||(opcode==ll)){ memtoReg =1;}
                else{memtoReg = 0;}

        if((opcode!=jal)&&(opcode!=sw)&&(opcode!=sh)&&(opcode!=sb)&&(opcode!=beq)&&(opcode!=bne)&&(opcode!=j)&&(funct!=jr)){ regWrite=1;}
               else{regWrite = 0;}

        if((opcode==lw)||(opcode==ll)||(opcode==lbu)||(opcode==lhu)){memRead = 1;}
                else{memRead = 0;}

        if((opcode==sw)||(opcode==sh)||(opcode==sb)){ memWrite=1;}
                else{memWrite=0;}

        if((opcode==j)||(opcode==jal)||(funct==jr)||(funct==jalr)){jump=1;}
                else{jump = 0;}

        if((opcode==bne)||(opcode==beq)){branch=1;}
                else{branch = 0;}

lat2[0].regDst=regDst;
lat2[0].aluSrc=aluSrc;
lat2[0].memtoReg=memtoReg;
lat2[0].memWrite=memWrite;
lat2[0].memRead=memRead;
lat2[0].regWrite=regWrite;
lat2[0].branch=branch;
lat2[0].jump=jump;
//print control signal
//printf("regdst %d, alusrc %d, memtoreg %d, regwrite %d, memread %d, memwrite %d, jump %d, branch %d \n", regDst,aluSrc, memtoReg,regWrite, memRead, memWrite, jump, branch );

return ;
}

